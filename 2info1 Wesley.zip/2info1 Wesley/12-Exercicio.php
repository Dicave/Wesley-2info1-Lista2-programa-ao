<?php

    $n = 0;
    for($n =0;$n <= 100;$n++){
        print $n;
    }