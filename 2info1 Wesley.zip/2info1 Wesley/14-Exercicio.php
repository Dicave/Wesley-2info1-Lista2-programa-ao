<?php



    $n=0;
    
   for($n = 0; $n < 50;$n++){
    
    if ( $n%2!=0){
        print "$n ";
    }
}