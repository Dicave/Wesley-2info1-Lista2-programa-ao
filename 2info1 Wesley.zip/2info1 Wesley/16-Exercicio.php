<?php



    print "Digite um número:\n";
        $num1 = (float)fgets(STDIN);
    
    print "Digite outro número:\n";
        $num2 = (float)fgets(STDIN);
    
    print "Digite outro número:\n";
        $num3 = (float)fgets(STDIN);
    
    print "Digite outro número:\n";
        $num4 = (float)fgets(STDIN);
    
    print "Digite outro número:\n";
        $num5 = (float)fgets(STDIN);
    
        $soma = $num1+$num2+$num3+$num4+$num5;
    
        $media = $soma/5;
    
    print "A soma de tudo é $soma, e a média é $media.\n\n";